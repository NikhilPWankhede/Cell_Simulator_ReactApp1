import React, { useCallback, useRef, useState } from 'react';
import produce from 'immer';

const numRows = 20;
const numCols = 20;
const operations = [
  [0,1],
  [0,-1],
  [1,-1],
  [-1,1],
  [1,1],
  [-1,-1],
  [1,0],
  [-1,0]
]

function createGrid(){ 
  const rows = [];
  for (let i=0; i<numRows;i++){
    rows.push(Array.from(Array(numCols), () => 0));
  }
  return rows;
}

function App(){
  const [grid, setGrid] = useState(createGrid);
  const [running, setRunning] = useState(false);
  const runningRef = useRef(running);
  runningRef.current = running
  const runSimulation = useCallback(() => {
    if (!runningRef.current){
      return;
    }
    setGrid(g =>{
      return produce(g, gridCopy => {
        for (let i=0; i <numRows; i++){
          for (let k=0; k<numCols; k++){
            let neighbors = 0;
            operations.forEach(([x,y]) => {
            const newI = i+x;
            const newK = k+y;
            if (newI >= 0 && newI <numRows && newK>=0 && newK <numCols){
              neighbors += g[newI][newK]
            }})
              
            if (neighbors ===3 && i===0)
              gridCopy[numRows-1][k]=1;
            else if (neighbors ===3 && i===numRows-1)
              gridCopy[0][k]=1;
            if (neighbors ===3 && k===0)
              gridCopy[i][numCols-1]=1;
            else if (neighbors ===3 && k===numCols-1)
              gridCopy[i][0]=1;                      
            if (neighbors <2 || neighbors >3)
              gridCopy[i][k] = 0;
            else if (g[i][k] === 0 && neighbors ===3)
              gridCopy[i][k] = 1;
          }
        }
      });
    });
    setTimeout(runSimulation, 500);
  },[])
  
  return (
    <>
    <h3 style={{textAlign:"center"}}>Cell Simulator</h3>
    <div style={{justifyContent: 'center',paddingLeft:580,paddingRight:580}}>
    <button 
      style={{justifyContent: 'center',margin:5}}
      title = "StartStopButton"
      onClick = {() => {
        setRunning(!running);
        if (!running){
        runningRef.current = true;
        runSimulation();
        }
      }}
    > 
    {running ? 'Stop' : 'Start'}
    </button>
    <button style={{alignSelf:'center', margin:5}} onClick = {()=>{setGrid(createGrid);}} title = "ResetButton">Reset</button>
    </div>
    <div style={{justifyContent:"center", display:"grid", padding:"10px", gridTemplateColumns: "repeat("+numCols+",20px)"}}>
      {grid.map((rows, i) =>
        rows.map((col, k) => (
        <div
          title = {i+"_"+k}
          key={i-k}
          onClick = {() =>{
            const newGrid = produce(grid,gridCopy =>{
              gridCopy[i][k]= grid[i][k] ? 0 : 1;
            })
            setGrid(newGrid);
          }}
          style={{width: 20, height: 20, backgroundColor: grid[i][k] ? "blue" : undefined, border: "solid 1px black"}}/>
        ))
      )}
   </div>
   </>
  );
};

export default App;
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';

it('checkStartStopButtonRender', () =>{
  const{ queryByTitle } = render(<App />);
  const ssbtn = queryByTitle("StartStopButton");
  expect(ssbtn).toBeTruthy();
})

it('checkResetButtonRender', () =>{
  const{ queryByTitle } = render(<App />);
  const rbtn = queryByTitle("ResetButton");
  expect(rbtn).toBeTruthy();
})


describe('clickStartButton', ()=>{
it('onClick', () => {
  const { queryByTitle } = render(<App />);
  let ssbtn: HTMLElement | null;
  ssbtn = queryByTitle("StartStopButton");
   expect(ssbtn?.innerHTML).toBe("Start");
  fireEvent.click(ssbtn);
  expect(ssbtn?.innerHTML).toBe("Stop");
});
});

describe('pattern1', ()=>{
  it('onClick', () => {
    const { queryByTitle } = render(<App />);
    const ssbtn = queryByTitle("StartStopButton");
    const c1 = queryByTitle("4_4");
    const c2 = queryByTitle("4_5");
    const c3 = queryByTitle("5_5");
    const c4 = queryByTitle("5_4");
    fireEvent.click(c1);
    fireEvent.click(c2);
    fireEvent.click(c3);
    expect(c1?.style.backgroundColor).toBe("blue");
    expect(c2?.style.backgroundColor).toBe("blue");
    expect(c3?.style.backgroundColor).toBe("blue");
    fireEvent.click(ssbtn);
    expect(c4?.style.backgroundColor).toBe("blue");
  });
  });

  describe('pattern2', ()=>{
    it('onClick', () => {
      const { queryByTitle } = render(<App />);
      const ssbtn = queryByTitle("StartStopButton");
      const pilot = ["3_3","4_4","5_2","5_3","5_4"]; 
      const generation1 = ["4_2","4_4","5_3","5_4","6_3"];
      const generation2 = ["4_4","5_2","5_4","6_3","6_4"];
      pilot.forEach((cell) => {
        const cNum = queryByTitle(cell);
        fireEvent.click(cNum);
        expect(cNum?.style.backgroundColor).toBe("blue");
      });
      fireEvent.click(ssbtn);
      fireEvent.click(ssbtn);
      generation1.forEach((cell) =>{
        const cNum = queryByTitle(cell);
        expect(cNum?.style.backgroundColor).toBe("blue");
      });
      fireEvent.click(ssbtn);
      fireEvent.click(ssbtn);
      generation2.forEach((cell) =>{
        const cNum = queryByTitle(cell);
        expect(cNum?.style.backgroundColor).toBe("blue");
      });
    });
  });